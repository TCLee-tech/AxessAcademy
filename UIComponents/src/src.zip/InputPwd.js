import React,{useState} from 'react';

export const PWDInput =(props) =>{
    const [pwd,setPWD] = useState("");

    const handleOnChangePWD=(e)=>{
        console.log(e);
        setPWD(e.target.value);
        
    }

    return (
        <React.Fragment>
            <div className="form-group">
                        <label>
                            Password:
                            <input type="text" 
                            name="pwd" 
                            id="InputPWD"
                            className="form-control" 
                            value={pwd}
                            onChange={handleOnChangePWD} />
                        </label>
                    </div>
        </React.Fragment>
        )
    }
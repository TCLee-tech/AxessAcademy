import React from "react";


export const ApplicationList = () => {

  const ApplicantList = [
    {
      cid :1,
      sino:"SI1",
      appid:"SC0001111",
      name:"Timothy Tan",
      status:"pending",
      age:24,
      agent:"Ankit"
    }
    ,
    {
      cid :2,
      sino:"SI2",
      appid:"SC0010001",
      name:"Andrew Lee",
      status:"pending",
      age:25,
      agent:"Eric"
    }
    ,
    {
      cid :3,
      sino:"SI3",
      appid:"SC0000101",
      name:"Lam Siu Hon",
      status:"pending",
      age:21,
      agent:"Samiya"
    }
    ,
    {
      cid :4,
      sino:"SI4",
      appid:"SC0000111",
      name:"Christine Teo",
      status:"pending",
      age:22,
      agent:"Ankit"
    }
    ,
    {
      cid :5,
      sino:"SI5",
      appid:"SC0001101",
      name:"Julienne Chor",
      status:"pending",
      age:23,
      agent:"Eric"
    }
    ,
    {
      cid :6,
      sino:"SI6",
      appid:"SC0000001",
      name:"Alex Seow",
      status:"pending",
      age:20,
      agent:"Samiya"
    }
    ,
    {
      cid :7,
      sino:"SI7",
      appid:"SC0010002",
      name:"Remy Lim",
      status:"pending",
      age:25,
      agent:"Samiya"
    },
  ];
  

  return (
   <React.Fragment>
       <div className="container">
        <table className="table table-striped">
            <thead>
              <tr>
                <th scope="col"></th>
                <th scope="col">SI. No.</th>
                <th scope="col">Application ID</th>
                <th scope="col">Card Holder Name</th>
                <th scope="col">Application Form Status</th>
                <th scope="col">Age of Application</th>
                <th scope="col">Handled By Sales User</th>
              </tr>
            </thead>
            </table>
            <div className="container-table">
              
              <table className="table table-striped">
                <thead>
                  <tr>
                    <th scope="col"></th>
                    <th scope="col"></th>
                    <th scope="col"></th>
                    <th scope="col"></th>
                    <th scope="col"></th>
                    <th scope="col"></th>
                    <th scope="col"></th>
                  </tr>
                </thead>
              <tbody>

              {ApplicantList.map((applicant,index)=>(
              <tr>
                <td><input type="checkbox" id={index}></input></td>
                <td>{applicant.sino}</td>
                <td>{applicant.appid}</td>
                <td>{applicant.name}</td>
                <td>{applicant.status}</td>
                <td>{applicant.age}</td>
                <td>{applicant.agent}</td>
              </tr>
              ))}
              
          </tbody>
        </table>
        </div>
    <button type="button" className="btn btn-success" >View/Edit Form</button>
    <button type="button" className="btn btn-light" >Create New</button>
    <button type="button" className="btn btn-secondary" >Download Report</button>
    </div>
    </React.Fragment>
  );
}



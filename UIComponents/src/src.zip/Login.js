import React,{useState} from 'react';
import {PSIDInput} from './InputPSID';
import {PWDInput} from './InputPwd';
import banner from './banner.png';

export const newLogin =(props)=>{
    const psid = PSIDInput.psid;
    const pwd = PWDInput.pwd;

    const handleSubmit=(e)=>{
        e.preventDefault();
            const newLogin= {
                psid,
                pwd
            }
        }

    return (
        <React.Fragment>
            <img src={banner} id="banner" alt="banner"></img>
            <div className="formbox">
                <form onSubmit={handleSubmit}>
                    <h4>Login</h4>
                    <PSIDInput />
                    <PWDInput />
                    <input type="submit" className="btn btn-primary" name="Submit" />
                </form>
            </div>
            
        </React.Fragment>
    );
}